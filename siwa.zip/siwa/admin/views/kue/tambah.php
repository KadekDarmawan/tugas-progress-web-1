<html>
<head>
    <title>tambah data</title>
</head>

<body>
    <a href="http://localhost/siwa/admin/?mod=kue">Back</a>
    <br/><br/>

    <form action="index.php?mod=kue&page=save" method="POST">
    <div class="col-md-6">
        <div class="form-group">
        <table width="25%" border="0">

            <tr> 
                <td>kode_kue</td>
                <td><input type="text" name="kode_kue"></td>
            </tr>
            <tr> 
                <td>nama_kue</td>
                <td><input type="text" name="nama_kue"></td>
            </tr>
            <tr> 
                <td>harga_satuan</td>
                <td><input type="text" name="harga_satuan"></td>
            </tr>
        </table>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Save</button>
    </div>
    </form>

    <?php
    if(isset($_POST['Submit'])) {
        $kode_kue= $_POST['kode_kue'];
        $nama_kue = $_POST['nama_kue'];
        $harga_satuan = $_POST['harga_satuan'];
        include_once("config.php");

        $result = mysqli_query($mysqli, "INSERT INTO users(kode_kue,nama_kue,harga_satuan) VALUES('$kode_kue','$nama_kue','$harga_satuan')");

        echo "User added successfully. <a href='http://localhost/siwa/admin/?mod=kue'>View Users</a>";
    }
    ?>
</body>
</html>