<?php 
session_destroy();
header('Location: http://localhost/SIWA/admin');
?>