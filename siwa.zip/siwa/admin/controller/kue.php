<?php
$con->auth();
$conn=$con->koneksi();
switch (@$_GET['page']){
    case 'add';
    $sql="select * from kue";
        $spesialis=$conn->query($sql);
        $content="views/kue/tambah.php";
        include_once 'views/template.php';
break;
case 'save':
    $kue ="save from kue where kue='$_GET[id]'";
    $kue=$conn->query($kue);
    header('Location: '.$con->site_url().'/admin/index.php?mod=kue');
        if($_SERVER['REQUEST_METHOD']=="POST"){
            //validasi
            if(empty($_POST['nama_kue'])){
                $err['nama_kue']="Nama kue Wajib";
            }
            if(empty($_POST['kode_kue'])){
                $err['kode_kue']="kode kue Wajib Angka";
            }
            if(empty($_POST['harga_satuan'])){
                $err['harga_satuan']="harga satuan Wajib Terisi";
            }
            if(!isset($err)){
                $id_login=$_SESSION['login']['id'];
                if(!empty($_POST['nama_kue'])){
                    //update
                    $sql="update kue set kode_kue='$_POST[kode_kue]',nama_kue='$_POST[nama_kue]', harga_satuan='$_POST[harga_satuan]',id_login=$id_login";
                }else{
                    //save
                    $sql = "INSERT INTO kue (kode_kue, nama_kue, harga_satuan) 
                    VALUES ('$_POST[kode_kue]','$_POST[nama_kue]','$_POST[harga_satuan]')";
                }
                    if ($conn->query($sql) === TRUE) {
                        header('Location: '.$con->site_url().'/admin/index.php?mode=kue');
                    } else {
                        $err['msg']= "Error: " . $sql . "<br>" . $conn->error;
                    }
            }
        }else{
            $err['msg']="tidak diijinkan";
        }
        if(isset($err)){
            include_once 'views/kue/tambah.php';
        }
    break;
case 'edit':
    $kue ="select * from kue where kode_kue='$_GET[id]'";
    $kue=$conn->query($kue);
    $_POST=$kue->fetch_assoc();
    $_POST['nama_kue']=$_POST['nama_kue'];
    $_POST['harga_satuan']=($_POST['harga_satuan']);
    //var_dump($kue);
    $kue="select * from ref_kue";
    $kue=$conn->query($kue);
    $sql="select * from ref_nama_kue";
    $nama_kue=$conn->query($sql);
    $content="views/kue/tambah.php";
    include_once 'views/template.php';
    break;
    case 'delete';
        $kue ="delete from kue where kode_kue='$_GET[id]'";
        $kue=$conn->query($kue);
        header('Location: '.$con->site_url().'/admin/index.php?mod=kue');
break;
default;
$sql="select * from kue";
$kue=$conn->query($sql);
$conn->close();
$content="views/kue/tampil.php";
include_once 'views/template.php';
}
?>



